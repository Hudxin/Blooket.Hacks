Join the Discord for support: https://discord.gg/UJSpqBNghy

if you get banned this is not my issue, as these are against Blooket's TOS

-lol-jude
